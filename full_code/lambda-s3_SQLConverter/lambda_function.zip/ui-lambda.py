import streamlit as st
import boto3

def upload_to_s3(file_path):
    # Replace 'your-bucket-name' with your actual S3 bucket name
    bucket_name = 'example-952640511403'
    s3_client = boto3.client('s3')
    with open(file_path, 'rb') as file:
        s3_client.upload_fileobj(file, bucket_name, file.name)

def main():
    st.title('File Uploader to AWS S3')

    uploaded_files = []
    more_files = True

    while more_files:
        file = st.file_uploader('Upload File', type=['txt', 'pdf', 'csv'])
        if file is not None:
            uploaded_files.append(file)
            st.write('File uploaded:', file.name)
            more_files = st.button('Upload More Files')

    if uploaded_files:
        if st.button('Confirm Upload to S3'):
            for file in uploaded_files:
                upload_to_s3(file.name)
            st.success('Files successfully uploaded to AWS S3!')

    if st.button('Show Files in S3 Bucket'):
        # Code to retrieve and display files from S3 bucket
        pass

if __name__ == '__main__':
    main()
